import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchPipe } from './pipes/search.pipe';
import { SortPipe } from './pipes/sort.pipe';
import { MycolorDirective } from './directives/mycolor.directive';
import { CoursesearchPipe } from './pipes/coursesearch.pipe';
import { CoursesortPipe } from './pipes/coursesort.pipe';
@NgModule({
  declarations: [
    SearchPipe,
    SortPipe,
    MycolorDirective,
    CoursesearchPipe,
    CoursesortPipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    SearchPipe,
    SortPipe,
    MycolorDirective,
    CoursesearchPipe,
    CoursesortPipe
  ]
})
export class SharedModule { }
